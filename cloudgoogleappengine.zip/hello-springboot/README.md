# Spring Boot Hello World Example with JSP

## Guide
https://hellokoding.com/spring-boot-hello-world-example-with-jsp/

## What you'll need
- JDK 1.7 or later
- Maven 3 or later

## Stack
- Spring Boot
- Java

## Run
`mvn spring-boot:run`
